---
id: cor:espacio-metrico
tipo: corolario
titulo: Espacio métrico
categorias: [Topología, Espacios métricos]
tags: [desigualdad triangular, métrica, espacio métrico]
referencia:
    bibkey: rudin1991functional 
    autor: Wilkiewicz
    año: 2019
    obra: Curso de análisis y 150 problemas resueltos
    edición: 1
    capitulo: 1
    pagina: 9   
creado_a_partir_de: [-,-,-,-,-]
inspirado_en: [-,--,-]
enlaces_entrada: [-,-,-,-,-]
enlaces_salida: [-,-,-,-,-]
---
\begin{corollary}
Enunciado aquí...
Enunciado aquí...
Enunciado aquí...
Enunciado aquí...
Enunciado aquí...
\begin{proof}
Demostración aquí...
\end{proof}
\end{corollary}

