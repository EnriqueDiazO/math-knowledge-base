---
id: def:conjuntosaaa007
tipo: definicion
titulo: Conjunto Ordenado
categorias:
- Topología
- Conjuntos Ordenados
- Orden
tags:
- orden
referencia:
  bibkey: rudin1964principles,
  autor: Rudin, W.
  año: 1964
  obra: Principles of Mathematical Analysis
  edición: 3
  capitulo: 1
  pagina: 3
creado_a_partir_de:
- '-'
- '-'
- '-'
- '-'
- '-'
inspirado_en:
- '-'
- --
- '-'
enlaces_entrada:
- 'def:conjuntosaaa006'
- 'def:conjuntosaaa001'
- '-'
- '-'
- '-'
enlaces_salida:
- '-'
- '-'
- '-'
- '-'
- '-'
---

\begin{definition}
Un conjunto ordenado es un conjunto $S$ donde un orden está definido.
\end{definition}