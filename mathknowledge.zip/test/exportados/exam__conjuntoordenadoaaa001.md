---
id: exam:conjuntoordenadoaaa001
tipo: ejemplo
titulo: Números racionales
categorias:
- Topología
- Conjuntos Ordenados
- Orden
tags:
- orden
referencia:
  bibkey: rudin1964principles,
  autor: Rudin, W.
  año: 1964
  obra: Principles of Mathematical Analysis
  edición: 3
  capitulo: 1
  pagina: 3
creado_a_partir_de:
- '-'
- '-'
- '-'
- '-'
- '-'
inspirado_en:
- '-'
- --
- '-'
enlaces_entrada:
- 'def:conjuntosaaa007'
- '-'
- '-'
- '-'
- '-'
enlaces_salida:
- '-'
- '-'
- '-'
- '-'
- '-'
---

\begin{example}
Los números racionales $\mathbb{Q}$ es un conjunto ordenado si $r < s$ se define como $s - r$ es un número racional positivo.
\end{example}